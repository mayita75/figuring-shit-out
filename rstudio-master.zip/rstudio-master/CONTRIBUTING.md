We welcome contributions to RStudio. To submit a contribution:

1. [Fork](https://github.com/rstudio/rstudio/fork) the repository and make your changes.

2. Ensure that you have signed the [individual](https://rstudioblog.files.wordpress.com/2017/05/rstudio_individual_contributor_agreement.pdf) or [corporate](https://rstudioblog.files.wordpress.com/2017/05/rstudio_corporate_contributor_agreement.pdf) contributor agreement as appropriate. You can send the signed copy to jj@rstudio.com.

3. Submit a [pull request](https://help.github.com/articles/using-pull-requests).

We'll try to be as responsive as possible in reviewing and accepting pull requests. Appreciate your contributions very much!


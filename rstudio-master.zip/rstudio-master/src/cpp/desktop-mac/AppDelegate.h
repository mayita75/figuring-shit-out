


#import <AppKit/NSApplication.h>

@interface AppDelegate : NSObject <NSApplicationDelegate> {
   NSString* openFile_;
   NSMenu* dockMenu_;
   BOOL initialized_;
}
@end


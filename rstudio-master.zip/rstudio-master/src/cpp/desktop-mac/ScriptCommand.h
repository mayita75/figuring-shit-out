#import <Foundation/Foundation.h>

@interface evaluateRScriptCommand : NSScriptCommand

-(id) performDefaultImplementation;

@end
